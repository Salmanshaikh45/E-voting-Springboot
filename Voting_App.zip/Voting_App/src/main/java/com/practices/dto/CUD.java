package com.practices.dto;



import com.practices.Validation.Phone;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data

public class CUD {

	@Size(min=8)
	private String UserName;
	
	
	private String password;
	
	
	@Email
	private String email;
	
	@Phone
	private String PhoneNo;
}
