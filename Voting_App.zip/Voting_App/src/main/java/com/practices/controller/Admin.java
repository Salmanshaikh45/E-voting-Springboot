package com.practices.controller;


import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.practices.dto.Ad_CUD;
import com.practices.service.Admin_ser;

import jakarta.validation.Valid;

@Controller
@RequestMapping("admin")
public class Admin {
	@Autowired
	Admin_ser as = new Admin_ser();
	
	@GetMapping("")
	public String login()
	{
		return "ad_log";
	}
	
	@GetMapping("/register")
	public String reg()
	{
		return "Ad_Register";
	}
	
	@PostMapping("/login")
	public ModelAndView log(@RequestParam("uname") String uname,@RequestParam("pass") String pass)
	{
		ModelAndView mv1 = new ModelAndView("redirect:/admin/list");
		ModelAndView mv2 = new ModelAndView("ad_log");
		
		boolean A = as.auth(uname, pass);
		if (A==true) {
			return mv1;
		}
		mv2.addObject("msg","Invaid UserName or Password");
		return mv2;
	}
	
	@PostMapping("/register")
	public ModelAndView Register( @RequestParam("uname") String uname,@RequestParam("pass") String pass,@RequestParam("email") String email,@RequestParam("phone") String phone)
	{
		try {
			ModelAndView mv = new ModelAndView("Ad_Register");
			mv.addObject("msg1","registered Succesfully");
		@Valid
		Ad_CUD cud = new Ad_CUD();
		cud.setUserName(uname);
		cud.setPassword(pass);
		cud.setEmail(email);
		cud.setPhoneNo(phone);
		as.register(cud);
		return mv;
		}
		catch (Exception e) {
			ModelAndView mv1 = new ModelAndView("Ad_Register");
			mv1.addObject("msg1","Something went wrong Please fill the detils properly");
			return mv1;
		}
	}
	
	@GetMapping("/list")
	public ModelAndView VoteCounts()
	{
		Map<String, Integer> list1 = new HashMap<>();
		list1=as.totalvotes();
		
		ModelAndView mv= new ModelAndView("list");
		mv.addObject("votes", list1);
		return mv;
	}

	
}
