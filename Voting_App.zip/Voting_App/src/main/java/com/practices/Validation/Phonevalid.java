package com.practices.Validation;




import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class Phonevalid implements ConstraintValidator<Phone,String>{

	

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		// TODO Auto-generated method stub
		if (value==null)
		{
			return true;
		}
		return value.length()==10 && value.matches("[0-9]+");
	}
	
}
