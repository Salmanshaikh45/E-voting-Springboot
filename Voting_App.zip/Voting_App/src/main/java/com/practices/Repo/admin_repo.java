package com.practices.Repo;

import org.springframework.data.repository.CrudRepository;

import com.practices.models.Admin_model;

public interface admin_repo extends CrudRepository<Admin_model, Integer>{

	Admin_model findByuserName(String name);
	

}
