package com.practices.Repo;

import org.springframework.data.repository.CrudRepository;

import com.practices.models.Votes;

public interface Vote_repo extends CrudRepository<Votes, Integer>{

	int countBycandidates(String candidate);
}
