package com.practices.Repo;

import org.springframework.data.repository.CrudRepository;

import com.practices.models.Student_model;

public interface Student_Repo extends CrudRepository<Student_model, Integer> {
	
	Student_model findByuserName(String uname);
}
