package com.practices.service;


import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.practices.Repo.Vote_repo;
import com.practices.Repo.admin_repo;
import com.practices.dto.Ad_CUD;

import com.practices.models.Admin_model;


@Service
public class Admin_ser {

	@Autowired
	Vote_repo vr;
	
	@Autowired
	admin_repo ad;
	
	
	
	Map<String,Integer> list =new HashMap<>();
	
	public Map<String, Integer> totalvotes()
	{
		
		int C1 = vr.countBycandidates("Candidate 1");
		int C2= vr.countBycandidates("Candidate 2");
		int C3= vr.countBycandidates("Candidate 3");
		int C4= vr.countBycandidates("Candidate 4");
		
		list.put("Candidate1",C1);
		list.put("Candidate2",C2);
		list.put("Candidate3",C3);
		list.put("Candidate4",C4);
		return list;
		
		 
	}
	
	
	
	public boolean auth(String name, String pass)
	{
		Admin_model am= new Admin_model();
		 am = ad.findByuserName(name);
		 if (name.equals(am.getUserName())&& pass.equals(am.getPassword()))
		 {
			 return true;
		 }
		 return false;
	}

	public String register(Ad_CUD cud)
	{	
		Admin_model sm = new Admin_model();
		sm.setUserName(cud.getUserName());
		sm.setPassword(cud.getPassword());
		sm.setEmail(cud.getEmail());
		sm.setPhoneNo(cud.getPhoneNo());
		ad.save(sm);
		return "Registered";
		
	}
		
	
	
	
	
}
