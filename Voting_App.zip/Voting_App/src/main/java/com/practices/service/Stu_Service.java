package com.practices.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.practices.Repo.Student_Repo;
import com.practices.Repo.Vote_repo;
import com.practices.dto.CUD;
import com.practices.models.Student_model;
import com.practices.models.Votes;

@Service
public class Stu_Service {
	@Autowired
	Student_Repo sr;
	
	@Autowired
	Vote_repo vr;

	public String register(CUD cud)
	{
		Student_model sm = new Student_model();
		sm.setUserName(cud.getUserName());
		sm.setPassword(cud.getPassword());
		sm.setEmail(cud.getEmail());
		sm.setPhoneNo(cud.getPhoneNo());
		sr.save(sm);
		return "Registered";
	}
	
	public boolean auth(String name, String pass)
	{
		Student_model sm = new Student_model();
		 sm = sr.findByuserName(name);
		 if (name.equals(sm.getUserName())&& pass.equals(sm.getPassword()))
		 {
			 return true;
		 }
		 return false;
	}
	
	public boolean votings(String uname,String candidate)
	{
		Votes v = new Votes();
		v.setUserName(uname);
		v.setCandidates(candidate);
		vr.save(v);
		return true;
		
	}
	
	
	
}
