package com.practices.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.practices.dto.CUD;
import com.practices.models.Candidate;
import com.practices.service.Stu_Service;

import jakarta.validation.Valid;



@Controller
public class Student_Controller {
	
	@Autowired
	Stu_Service ss= new Stu_Service();
	
	@GetMapping("/")
	public String login()
	{
		return "index";
	}
	
	@GetMapping("/reg")
	public String reg()
	{
		return "Register";
		
	}
	
	 
	@PostMapping("/reg")
	public ModelAndView Register( @RequestParam("uname") String uname,@RequestParam("pass") String pass,@RequestParam("email") String email,@RequestParam("phone") String phone)
	{
		try {
			ModelAndView mv = new ModelAndView("index");
			mv.addObject("msg","Registerd Successfully");
		
		CUD cud = new CUD();
		cud.setUserName(uname);
		cud.setPassword(pass);
		cud.setEmail(email);
		cud.setPhoneNo(phone);
		ss.register(cud);
		return mv;}
		catch (Exception e) {
			// TODO: handle exception
			ModelAndView mv = new ModelAndView("Register");
			mv.addObject("msg","Something went wrong Please fill the detils properly");
			return mv;
		}
	}
	
	@PostMapping("/log")
	public ModelAndView log(@RequestParam("uname") String uname,@RequestParam("pass") String pass)
	{
		ModelAndView mv1 = new ModelAndView("redirect:/vote");
		ModelAndView mv2 = new ModelAndView("index");
		
		boolean A = ss.auth(uname, pass);
		if (A==true) {
			mv1.addObject("name",uname);
			return mv1;
		}
		mv2.addObject("msg","Invaid UserName or Password");
		return mv2;
	}
	
	@GetMapping("/vote")
	public ModelAndView vote()
	{
		Iterable<Candidate> c = this.ss.fetchall();
		ModelAndView mv =new ModelAndView("vote");
		mv.addObject("can",c);
		return mv;
	}
	
	@PostMapping("/vote")
	public ModelAndView voted(@RequestParam("uname") String uname,@RequestParam("votes") String candidate)
	{
		try {
		ss.votings(uname, candidate);
		ModelAndView mv =  new ModelAndView("vote");
		mv.addObject("msg1","Thank You for Voting");
		return mv;
		}
		catch (Exception e) {
			// TODO: handle exception
		ModelAndView mv =  new ModelAndView("vote");
				mv.addObject("msg","You can Vote only One Time");
				return  mv;
		}
	}
}
