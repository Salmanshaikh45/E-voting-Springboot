package com.practices.service;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.practices.Repo.Vote_repo;
import com.practices.Repo.admin_repo;
import com.practices.Repo.candidate_Repo;
import com.practices.controller.Admin;
import com.practices.dto.Ad_CUD;

import com.practices.models.Admin_model;
import com.practices.models.Candidate;
import com.practices.models.counts;


@Service
public class Admin_ser {
	
	@Autowired
	candidate_Repo cdr;

	@Autowired
	Vote_repo vr;
	
	@Autowired
	admin_repo ad;
	
	
	
	public List<Object[]> counting()
	{
		return  vr.countVOTESBycandidates();
	}
	
	
	
	public boolean auth(String name, String pass)
	{
		Admin_model am= new Admin_model();
		 am = ad.findByuserName(name);
		 if (name.equals(am.getUserName())&& pass.equals(am.getPassword()))
		 {
			 return true;
		 }
		 return false;
	}

	public String register(Ad_CUD cud)
	{	
		Admin_model sm = new Admin_model();
		sm.setUserName(cud.getUserName());
		sm.setPassword(cud.getPassword());
		sm.setEmail(cud.getEmail());
		sm.setPhoneNo(cud.getPhoneNo());
		ad.save(sm);
		return "Registered";
		
	}
	
	public boolean candidate(String Name)
	{
		Candidate cd=new Candidate();
		cd.getCdname();
		cdr.save(cd);
		return true;
	}
		
	
	public Iterable<Candidate> fetchall()
	{
		return this.cdr.findAll();
	}
	
	public Candidate findbyname(String name)
	{
		return this.cdr.findByCdname(name);
	}
	
  public String cdregister(Candidate cd) {
		
	  cdr.save(cd);
	  return "Register Successfullyy..";
	}
	
	public String cdupdate(String name, int id,int age,String Qualification) {
		
		Candidate cd =this.cdr.findByCdname(name);
		
		cd.setId(id);
		cd.setCdname(name);	
		cd.setAge(age);
		cd.setQualification(Qualification);
		cdr.save(cd);
		return "";
	}
	
	public String deleteByID(int id )
	{
		cdr.deleteById(id);
		return "deleted";
	}
	
//	public Iterable<Candidate> getAllCandidate()
//	{
//	 return  cdr.findAll();
//	}
//	
	
}
