package com.practices.Repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.practices.models.Votes;
import com.practices.models.counts;

public interface Vote_repo extends CrudRepository<Votes, Integer>{

	
	
	
	@Query("Select c.cdname, count(v.candidates) as Vote from VOTES v, Candidate c where c.cdname = v.candidates  group by c.cdname")
	List<Object[]> countVOTESBycandidates();
}
