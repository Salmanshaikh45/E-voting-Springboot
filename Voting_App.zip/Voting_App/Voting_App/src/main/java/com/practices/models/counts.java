package com.practices.models;

import lombok.Data;

@Data
public class counts {

	private String can;
	private int count;
	
}
