package com.practices.controller;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.practices.dto.Ad_CUD;
import com.practices.models.Candidate;
import com.practices.models.counts;
import com.practices.service.Admin_ser;

import jakarta.validation.Valid;
import jakarta.websocket.server.PathParam;

@RestController
@RequestMapping("admin")
public class Admin {
	@Autowired
	Admin_ser as = new Admin_ser();
	
	@GetMapping("/home")
	public ModelAndView home() {
		ModelAndView mv= new ModelAndView("home");
		return mv;
	}
	
	@GetMapping("")
	public ModelAndView login()
	{
		
		ModelAndView mv= new ModelAndView("ad_log");
		return mv;
	}
	
	@GetMapping("/register")
	public ModelAndView reg()
	{
		ModelAndView mv= new ModelAndView("Ad_Register");
		return mv;
	}
	
	@PostMapping("/login")
	public ModelAndView log(@RequestParam("uname") String uname,@RequestParam("pass") String pass)
	{
		ModelAndView mv1 = new ModelAndView("redirect:/admin/candidates");
		ModelAndView mv2 = new ModelAndView("ad_log");
		
		boolean A = as.auth(uname, pass);
		if (A==true) {
			return mv1;
		}
		mv2.addObject("msg","Invaid UserName or Password");
		return mv2;
	}
	
	@PostMapping("/register")
	public ModelAndView Register( @RequestParam("uname") String uname,@RequestParam("pass") String pass,@RequestParam("email") String email,@RequestParam("phone") String phone)
	{
		try {
			ModelAndView mv = new ModelAndView("Ad_Register");
			mv.addObject("msg1","registered Succesfully");
		@Valid
		Ad_CUD cud = new Ad_CUD();
		cud.setUserName(uname);
		cud.setPassword(pass);
		cud.setEmail(email);
		cud.setPhoneNo(phone);
		as.register(cud);
		return mv;
		}
		catch (Exception e) {
			ModelAndView mv1 = new ModelAndView("Ad_Register");
			mv1.addObject("msg1","Something went wrong Please fill the detils properly");
			return mv1;
		}
	}
	
	@GetMapping("/list")
	public ModelAndView VoteCounts()
	{
		List<Object[]> list1 = new ArrayList<>();
		list1=as.counting();
		
		ModelAndView mv= new ModelAndView("list");
		mv.addObject("votes", list1);
		return mv;
	}

	@GetMapping("/candidates")
	public ModelAndView canlist()
	{
		Iterable<Candidate> c = this.as.fetchall();
		ModelAndView mv = new ModelAndView("Canlist");
		mv.addObject("can",c);
		return mv;
	}
	
	@GetMapping("/cdreg")
	public ModelAndView cdreg() {
		return new ModelAndView("cdregister");
	}
	
	@PostMapping("/cdreg")
	
	public ModelAndView cdregister(@RequestParam ("cdname") String cdname,@RequestParam("age") int age,@RequestParam("Qualification")String Qualification)
	{
		Candidate cd=new Candidate();
		cd.setCdname(cdname);
		cd.setAge(age);
		cd.setQualification(Qualification);
		as.cdregister(cd);
		ModelAndView mv=new ModelAndView("cdregister");
		mv.addObject("msg"," Register Sucessfully");
		return mv;
	}
	
	
	@GetMapping("/cdup/{cdname}")
	public ModelAndView updatepage(@PathVariable("cdname") String id)
	{
		Candidate c= this.as.findbyname(id);
	
		ModelAndView mv = new ModelAndView("updatecandidate");
		mv.addObject("can",c); 
		return mv;
	}
	
	@PostMapping("/cdup/{cdname}")
	
	public ModelAndView Update(@PathVariable ("cdname") String cdname,@RequestParam("name")String name,@RequestParam("Age")int age,@RequestParam("Qualification") String Qualification)
	{
		ModelAndView mv=new ModelAndView("redirect:../candidates");
		
		
		
		Candidate cd =this.as.findbyname(cdname);
		
		cd.setCdname(name);
		cd.setAge(age);
		cd.setQualification(Qualification);
		as.cdregister(cd);
		mv.addObject("msg1","Update SuccesFully..");
		
		
		
		
		return mv;
		
	}
	
	@RequestMapping("/cddelete/{id}")
	public ModelAndView cnddelete(@PathVariable("id")int id)
	{
		as.deleteByID(id );
		return new ModelAndView("redirect:../candidates") ;
	}
	
	
}
