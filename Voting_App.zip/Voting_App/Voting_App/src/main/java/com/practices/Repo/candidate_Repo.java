package com.practices.Repo;

import org.springframework.data.repository.CrudRepository;

import com.practices.models.Candidate;


public interface candidate_Repo extends CrudRepository<Candidate, Integer> {
	
	Candidate findByCdname(String cdname);
	
}
