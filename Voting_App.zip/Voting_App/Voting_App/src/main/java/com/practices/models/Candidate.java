package com.practices.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Min;
import lombok.Data;

@Data
@Entity
public class Candidate {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	
	@Column(name="Name", unique = true)
	private String cdname;
	
	@Column(name="Age")
	@Min(value=18,message ="Age Should be greater than are equal to 18 ")
	private int age;
	
	
	@Column(name="Qualification")
	private String Qualification;

}
